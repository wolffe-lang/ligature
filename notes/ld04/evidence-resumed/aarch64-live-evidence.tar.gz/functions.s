.text
.global read_values, finish
read_values:
 adrp x3, value
 ldr x0, [x3, :lo12:value]
 adrp x4, :got:extra
 ldr x4, [x4, :got_lo12:extra]
 ldr x5, [x4]
 add x0, x0, x5
 ret
finish:
 cmp x0, #42
 b.ne failure
 mov x0, #0
 mov x8, #93
 svc #0
failure:
 mov x0, #99
 mov x8, #93
 svc #0
