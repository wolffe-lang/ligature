.text
.global _start
_start:
 adrp x1, message
 add x1, x1, :lo12:message
 mov x0, #1
 mov x2, #15
 mov x8, #64
 svc #0
 bl read_values
 b finish
.data
.global absolute_pointer, relative_pointer
absolute_pointer: .quad message
relative_pointer: .word finish - .
