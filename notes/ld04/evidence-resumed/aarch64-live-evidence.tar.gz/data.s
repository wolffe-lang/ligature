.section .rodata,"a",@progbits
.global message
message: .asciz "hello, AArch64\n"
.data
.balign 8
.global value, extra
value: .quad 40
extra: .quad 2
